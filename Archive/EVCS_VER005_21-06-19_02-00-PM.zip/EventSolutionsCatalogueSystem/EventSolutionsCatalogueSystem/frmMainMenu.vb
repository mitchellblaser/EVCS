﻿Public Class frmMainMenu
    Public selectedTask As String
    Private Sub btnAddClient_Click(sender As Object, e As EventArgs) Handles btnAddClient.Click
        selectedTask = "AddClient"
        frmDataEntry.Show()
    End Sub

    Private Sub btnAddEquipment_Click(sender As Object, e As EventArgs) Handles btnAddEquipment.Click
        selectedTask = "AddEquipment"
        frmDataEntry.Show()
    End Sub

    Private Sub btnAddHire_Click(sender As Object, e As EventArgs) Handles btnAddHire.Click
        selectedTask = "AddHire"
        frmDataEntry.Show()
    End Sub
End Class