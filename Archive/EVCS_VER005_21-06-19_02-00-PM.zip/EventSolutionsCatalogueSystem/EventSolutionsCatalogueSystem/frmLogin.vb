﻿Imports System.IO

Public Class frmLogin
    Public evRootPath As String = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) & "\EventSolutions"
    Dim userStorePath As String = evRootPath & "\userstore\userstore.txt"
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        evLogin()
    End Sub

    Sub evLogin()
        'TODO' Add dedcryption algorithm here. For now I'll just use plain text.

        Dim usernameLine As String
        Dim passwordLine As String

        Using fileRead As New StreamReader(userStorePath, True) 'Recursively loop until a username matches what's been entered
            usernameLine = fileRead.ReadLine()
            passwordLine = fileRead.ReadLine()

            If usernameLine = txtUser.Text Then
                If passwordLine = txtPass.Text Then
                    frmMainMenu.Show()
                    Me.Hide()
                Else
                    MsgBox("Username and Password do not match.")
                End If
            Else
                MsgBox("Username not recognized.")
            End If
        End Using
    End Sub

    Private Sub btnQuit_Click(sender As Object, e As EventArgs) Handles btnQuit.Click
        End
    End Sub

    Private Sub txtPass_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtPass.KeyPress
        If e.KeyChar = Microsoft.VisualBasic.ChrW(Keys.Return) Then
            evLogin()
        End If
    End Sub
End Class
