﻿Public Class frmMainMenu
    Private Sub btnAddClient_Click(sender As Object, e As EventArgs) Handles btnAddClient.Click
        frmDataEntry.Show()
    End Sub
End Class